interface apb_intf(input pclk,preset_n);
      logic [7:0]paddr;
      logic psel;
      logic pwrite;
      logic penable;
      logic [7:0]pw_data;

      //output signals
      logic[7:0]pr_data;
      logic pready;
      logic pslv_err;

endinterface


class apb_agent1 extends uvm_agent;
    
    `uvm_component_utils(apb_agent1)

      apb_driver dri;
      apb_monitor1 mon1;
      apb_sequencer sqr;
       
        function new(string name="apb_agent1",uvm_component parent);
           super.new(name,parent);
        endfunction

        function void build_phase(uvm_phase phase);
            super.build_phase(phase);
              dri=apb_driver::type_id::create("dri",this);
              mon1=apb_monitor1::type_id::create("mon1",this);
              sqr=apb_sequencer::type_id::create("sqr",this);
        endfunction
          
          function void connect_phase(uvm_phase phase);
             super.connect_phase(phase);
                dri.seq_item_port.connect(sqr.seq_item_export);
              
          endfunction

          
endclass

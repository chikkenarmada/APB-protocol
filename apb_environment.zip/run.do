vlog uvm_top.sv +acc
vsim apb_top
add wave -r /*
run -all

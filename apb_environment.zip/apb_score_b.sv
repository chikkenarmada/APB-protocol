class apb_score_board extends uvm_scoreboard;
 
   `uvm_component_utils(apb_score_board)
      
      apb_seq_item sc_tx;
          
              uvm_analysis_imp#(apb_seq_item,apb_score_board) sc_imp;

       function new(string name="apb_score_board",uvm_component parent);
          super.new(name,parent);
          sc_imp=new("sc_imp",this);
       endfunction

          task run_phase(uvm_phase phase);
              super.run_phase(phase);
             sc_tx=apb_seq_item::type_id::create("sc_tx");
          endtask

          function void write(apb_seq_item tx);
              tx.print();
          endfunction
endclass

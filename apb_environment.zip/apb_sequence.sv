class apb_sequence extends uvm_sequence#(apb_seq_item);
  
        apb_seq_item s1;
        bit [7:0]pwdata;
        bit [7:0]paddr;
        int i,j;
        int num;
        logic[5:0] constant_data;

         string operation;
         string data_type;
         string addr_type;

        `uvm_declare_p_sequencer(apb_sequencer)
 
    `uvm_object_utils_begin(apb_sequence)
        `uvm_field_string(operation,UVM_DEFAULT)
        `uvm_field_string(data_type,UVM_DEFAULT)
        `uvm_field_string(addr_type,UVM_DEFAULT)
    `uvm_object_utils_end



      
      function new(string name="apb_sequence");
        super.new(name);
        i=0;
        j=0;
        num=10;
      endfunction

         task body();
           s1=apb_seq_item::type_id::create("s1");
               
               void'(p_sequencer.get_config_string("operation",operation));
               void'(p_sequencer.get_config_string("data_type",data_type));
               void'(p_sequencer.get_config_string("addr_type",addr_type));
            case(operation)
              "wr_rd":repeat(num)
                      begin
                       start_item(s1);
                       s1.pw_data=cal_pwdata(data_type);
                       s1.paddr=cal_paddr(addr_type);
                       s1.pwrite=1;
                       s1.psel=1;
                       s1.penable=0;
                       finish_item(s1);
                       #10;
                       start_item(s1);
                        s1.psel=1;
                        s1.penable=1;
                       finish_item(s1);
                      #10;
                      start_item(s1);
                        s1.pwrite=0;
                      finish_item(s1);
                      #10;
                      start_item(s1);
                        s1.psel=1;
                        s1.penable=1;
                       finish_item(s1);

                   end
               "wr":begin
                     end
               "rd":begin
                    end
            endcase        

         endtask
           
           virtual function bit[7:0] cal_pwdata(string data_type);
                   case(data_type)
                        "random":begin
                                   pwdata=$random;
                                   return pwdata;
                                 end
                     "increment":begin
                                 pwdata++;
                                 return pwdata;
                                 end
                     "decrement":begin
                                 pwdata--;
                                 return pwdata;
                                 end
                      "constant":begin
                                  pwdata=constant_data;
                                  return pwdata;
                                 end
                     endcase            
           endfunction
           virtual function bit[7:0] cal_paddr(string addr_type);
                   case(addr_type)
                        "random":begin
                                   paddr=$random;
                                   return paddr;
                                 end
                     "increment":begin
                                 paddr++;
                                 return paddr;
                                 end
                     "decrement":begin
                                 paddr--;
                                 return paddr;
                                 end
                      "constant":begin
                                  paddr=constant_data;
                                  return paddr;
                                 end
                    endcase             
           endfunction
        

        
                     
endclass

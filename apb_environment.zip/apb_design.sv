module apb(

     // input signals
      input pclk,
      input preset_n,
      input [7:0]paddr,
      input psel,
      input pwrite,
      input penable,
      input [7:0]pw_data,

      //output signals
      output reg[7:0]pr_data,
      output pready,
      output reg pslv_err
      );
      assign pready=(psel && penable);

     //memory declaration
     
     reg [7:0]mem[255:0];

    // assign pready=(sel && penable);

     //state declaration

     parameter[1:0] idle=2'b00;
     parameter[1:0] setup=2'b01;
     parameter[1:0] access=2'b10;

     //state declaration of present and next state
       
       reg[1:0] present_state,next_state;


       always @(posedge pclk)
         begin
            if(!preset_n)
                begin
                pr_data<=1;
               // pready<=0;
                pslv_err<=0;
                present_state<=idle;
                end
                else
                    begin
                    present_state<=next_state;
                    end
            if(present_state == access && psel && penable) begin
                if(pwrite)
                    mem[paddr[4:0]] <= pw_data; // write
                else
                    pr_data <= mem[paddr[4:0]]; // read
            end
         end 
      
      always @(*) begin
          next_state=present_state;
          pslv_err=0;
             case(present_state)
                idle:begin
                       if(psel & !penable)
                           next_state=setup;
                           else
                               next_state=idle;
                     end
               setup:begin
                        if(psel && penable)
                            begin
                             next_state=access;
                            end
                            else if(psel && !penable)
                                next_state=setup;
                           else 
                            next_state=idle;
                     end
               access:begin
                         if(psel && penable)
                           begin    
                             if(pwrite)
                                mem[paddr]<=pw_data;
                                 else
                                   pr_data<=mem[paddr];
                           end        
                        else if(psel && !penable)
                              begin
                                next_state=setup;
                              end
                              else
                                next_state=idle;
                        
                      end
                default:next_state=idle;      
        endcase                  
      end
endmodule

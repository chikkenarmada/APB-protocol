`include "apb_design.sv"
module tb;

 // input signals
      reg pclk;
      reg preset_n;
      reg [31:0]paddr;
      reg psel;
      reg pwrite;
      reg penable;
      reg [31:0]pw_data;

      //output signals
       wire[31:0]pr_data;
       wire pready;
       wire pslv_err;

       apb dut(.pclk(pclk),
               .preset_n(preset_n),
               .paddr(paddr),
               .psel(psel),
               .pwrite(pwrite),
               .penable(penable),
               .pw_data(pw_data),
               .pr_data(pr_data),
               .pready(pready),
               .pslv_err(pslv_err)
               );

       initial begin
       pclk=0;
       forever #5 pclk=~pclk;
       end
       initial begin
          preset_n=0;
          psel=0;
          penable=0;
          pwrite=0;
          pw_data=0;
           #20;
          preset_n=1; 
       end

       initial begin
          wait(preset_n==1);

             //write transaction
            @(posedge pclk);
              paddr=32'h0000_0004;
              pw_data=32'habcd_1234;
              pwrite=1;
              psel=1;
              penable=0;

              @(posedge pclk);
              penable=1;

              wait(pready==1);

            @(posedge pclk);
              psel=0;
              penable=0;

             @(posedge pclk);
               paddr=32'h0000_0004;
              // pw_data=32'hbcda_0123;
               pwrite=0;
               psel=1;
               penable=0;
              // pwrite=0;
             @(posedge pclk);
               penable=1;

               wait(pready==1);
                
                @(posedge pclk);
                    psel=0;
                    penable=0;

#100;
  $finish;



       end

endmodule

class apb_monitor2 extends uvm_monitor;
  
  `uvm_component_utils(apb_monitor2);
      
         virtual apb_intf m2;
    
      apb_seq_item moni2;

           uvm_analysis_port#(apb_seq_item) m2_port;
     
      function new(string name="apb_monitor",uvm_component parent);
         super.new(name,parent);
         m2_port=new("m2_port",this);
      endfunction

       function void build_phase(uvm_phase phase);
           super.build_phase(phase);
              if(!uvm_config_db#(virtual apb_intf)::get(this,"","apb_protocol",m2))
                   `uvm_fatal(get_type_name(),$sformatf("config db are not retrive"))
                   else
                       `uvm_info(get_type_name(),$sformatf("config db retrived"),UVM_NONE)

       endfunction

       task run_phase(uvm_phase phase);
         super.run_phase(phase);
          moni2=apb_seq_item::type_id::create("moni2");

           forever begin
              // @(m2.pr_data,m2.pready,m2.pslv_err)
                @(posedge m2.pclk)  
                 moni2.pr_data=m2.pr_data;
                 moni2.pready=m2.pready;
                 moni2.pslv_err=m2.pslv_err;
                 m2_port.write(moni2);
           end     
       endtask
endclass

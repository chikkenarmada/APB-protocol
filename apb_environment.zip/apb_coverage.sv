class apb_coverage extends uvm_component;
   
     `uvm_component_utils(apb_coverage)
        
        apb_seq_item cov;
           
             uvm_analysis_imp#(apb_seq_item,apb_coverage) m2c_imp;
        
         function new(string name="apb_coverage",uvm_component parent);
             super.new(name,parent);
               m2c_imp=new("m2c_imp",this);
         endfunction

            task run_phase(uvm_phase phase);
               super.run_phase(phase);
               cov=apb_seq_item::type_id::create("cov");
            endtask

            function void write(apb_seq_item c1);
               c1.print();
            endfunction
endclass

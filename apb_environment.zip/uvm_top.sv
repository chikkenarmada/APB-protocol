`include "uvm_macros.svh"
import uvm_pkg::*;
`include "apb_design.sv"
`include "apb_interface.sv"
`include "apb_seq_item.sv"
`include "apb_sequencer.sv"
`include "apb_sequence.sv"
`include "apb_driver.sv"
`include "apb_monitor1.sv"
`include "apb_monitor2.sv"
`include "apb_agent1.sv"
`include "apb_agent2.sv"
`include "apb_score_b.sv"
`include "apb_coverage.sv"
`include "apb_environment.sv"
`include "apb_test.sv"
module apb_top;
reg pclk,preset_n;

     apb_intf vif(.pclk(pclk),.preset_n(preset_n));
     apb dut(.paddr(vif.paddr),
             .pwrite(vif.pwrite),
             .penable(vif.penable),
             .psel(vif.psel),
             .pclk(vif.pclk),
             .preset_n(vif.preset_n),
             .pw_data(vif.pw_data),
             .pr_data(vif.pr_data),
             .pready(vif.pready),
             .pslv_err(vif.pslv_err)
             );
      
      initial begin
        pclk=0;
        forever #5 pclk=~pclk;
      end

      initial begin
         preset_n=0;
          #10;
         preset_n=1;
      end

      initial begin
         uvm_config_db#(virtual apb_intf)::set(uvm_root::get(),"*","apb_protocol",vif);
         run_test("apb_test");
      end
endmodule

class apb_monitor1 extends uvm_monitor;
  
  `uvm_component_utils(apb_monitor1);
      
         virtual apb_intf m1;
          apb_seq_item moni1;
     
             uvm_analysis_port#(apb_seq_item) m1all_port;
    
           function new(string name="apb_monitor",uvm_component parent);
              super.new(name,parent);
              m1all_port=new("m1all_port",this);
           endfunction

       function void build_phase(uvm_phase phase);
           super.build_phase(phase);
               if(!uvm_config_db#(virtual apb_intf)::get(this,"","apb_protocol",m1))
                   `uvm_fatal(get_type_name(),$sformatf("config db are not retrive"))
                   else
                       `uvm_info(get_type_name(),$sformatf("config db retrived"),UVM_NONE)
       endfunction

       task run_phase(uvm_phase phase);
         super.run_phase(phase);
         moni1=apb_seq_item::type_id::create("moni1");

           forever begin
          // @(m1.paddr,m1.psel,m1.pwrite,m1.pw_data,m1.penable)
          @(posedge m1.pclk)
                 moni1.paddr=m1.paddr;
                 moni1.psel=m1.psel;
                 moni1.pwrite=m1.pwrite;
                 moni1.pw_data=m1.pw_data;
                 moni1.penable=m1.penable;

                 m1all_port.write(moni1);
            end     
       endtask
endclass

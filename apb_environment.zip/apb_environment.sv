class apb_environment extends uvm_env;
   
    `uvm_component_utils(apb_environment)
      
        apb_agent1 a1;
        apb_agent2 a2;
        apb_score_board sb;
        apb_coverage cov;
       
       function new(string name="apb_environent",uvm_component parent);
         super.new(name,parent);
       endfunction
        
        function void build_phase(uvm_phase phase);
           super.build_phase(phase);
              a1=apb_agent1::type_id::create("a1",this);
              a2=apb_agent2::type_id::create("a2",this);
              sb=apb_score_board::type_id::create("sb",this);
              cov=apb_coverage::type_id::create("cov",this);
        endfunction

           function void connect_phase(uvm_phase phase);
                super.connect_phase(phase);
                  a1.mon1.m1all_port.connect(sb.sc_imp);
                  a1.mon1.m1all_port.connect(cov.m2c_imp);
                  a2.mon2.m2_port.connect(sb.sc_imp);
           endfunction

        

          
endclass

class apb_seq_item extends uvm_sequence_item;

       bit pclk;
      bit preset_n;
 rand bit [7:0]paddr;
      bit psel;
      bit pwrite;
      bit penable;
 rand bit [7:0]pw_data;

      //output signals
      bit[7:0]pr_data;
      bit pready;
      bit pslv_err;

   
   `uvm_object_utils_begin(apb_seq_item)
       `uvm_field_int(pclk,UVM_ALL_ON)
       `uvm_field_int(preset_n,UVM_ALL_ON)
       `uvm_field_int(paddr,UVM_ALL_ON)
       `uvm_field_int(psel,UVM_ALL_ON)
       `uvm_field_int(pwrite,UVM_ALL_ON)
       `uvm_field_int(penable,UVM_ALL_ON)
       `uvm_field_int(pw_data,UVM_ALL_ON)
       `uvm_field_int(penable,UVM_ALL_ON)
       `uvm_field_int(pw_data,UVM_ALL_ON)
       `uvm_field_int(pr_data,UVM_ALL_ON)
       `uvm_field_int(pready,UVM_ALL_ON)
       `uvm_field_int(pslv_err,UVM_ALL_ON)
   `uvm_object_utils_end

        function new(string name="apb_seq_item");
           super.new(name);
        endfunction
endclass

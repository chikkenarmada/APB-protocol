class apb_driver extends uvm_driver#(apb_seq_item);

    `uvm_component_utils(apb_driver)
      virtual apb_intf i1;
     
     apb_seq_item d1;

        
        function new(string name="apb_driver",uvm_component parent);
           super.new(name,parent);
        endfunction

           function void build_phase(uvm_phase phase);
               super.build_phase(phase);
               if(!uvm_config_db#(virtual apb_intf)::get(this,"","apb_protocol",i1))
                   `uvm_fatal(get_type_name(),$sformatf("config db are not retrive"))
                   else
                       `uvm_info(get_type_name(),$sformatf("config db retrived"),UVM_NONE)
           endfunction

           task run_phase(uvm_phase phase);
              super.run_phase(phase);
                 d1=apb_seq_item::type_id::create("d1");

                 forever begin
                     seq_item_port.get_next_item(d1);
                        i1.paddr=d1.paddr;
                        i1.pw_data=d1.pw_data;
                       // i1.pr_data=d1.pr_data;
                        i1.pwrite=d1.pwrite;
                        i1.psel=d1.psel;
                        i1.penable=d1.penable;
                       // i1.pready=d1.pready;
                        //i1.pslv_err=d1.pslv_err;
                         #20;
                         
                    seq_item_port.item_done();
                   end 
           endtask



endclass

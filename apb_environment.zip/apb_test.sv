class apb_test extends uvm_test;

    `uvm_component_utils(apb_test)

        apb_sequence seq;
        apb_environment env;
       
       function new(string name="apb_test",uvm_component parent);
          super.new(name,parent);
       endfunction

       virtual function void build_phase(uvm_phase phase);
           super.build_phase(phase);
           env=apb_environment::type_id::create("env",this);
           set_config_string("env.a1.sqr","operation","wr_rd");
           set_config_string("env.a1.sqr","data_type","random");
           set_config_string("env.a1.sqr","addr_type","random");
       endfunction

       function void strat_of_simulation_phase(uvm_phase phase);
           super.start_of_simulation_phase(phase);
            uvm_top.print_topology();
       endfunction

        task run_phase(uvm_phase phase);
            super.run_phase(phase);
            seq=apb_sequence::type_id::create("seq");

              phase.raise_objection(this);
                  seq.start(env.a1.sqr);
                   #20;
              phase.drop_objection(this);     
        endtask

         
endclass
